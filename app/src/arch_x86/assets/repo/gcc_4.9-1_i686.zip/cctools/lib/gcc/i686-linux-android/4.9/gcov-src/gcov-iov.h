/* Generated automatically by the program `build/gcov-iov'
   from `4.9 (4 9) and prerelease (*)'.  */

#define GCOV_VERSION ((gcov_unsigned_t)0x3430392a)  /* 409* */
