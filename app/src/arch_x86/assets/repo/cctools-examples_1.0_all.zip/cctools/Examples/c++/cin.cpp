using namespace std; 
#include <iostream>

int main() { 
  int a;
  char s [100];

  cout << "This is a sample program." << endl;

  cout << endl;

  cout << "Type your age : " << endl; 
  cin >> a;

  cout << "Type your name: \n"; 
  cin >> s;

  cout << endl;

  cout << "Hello " << s << " you're " << a << " old." << endl; 
  cout << endl << endl << "Bye!" << endl;

  return 0;
}
