/* Generated automatically. */
static const char configuration_arguments[] = "../configure --target=arm-linux-androideabi --enable-static --disable-shared --enable-languages=c,c++ --enable-initfini-array --disable-lto --with-float=soft --with-fpu=vfp --with-arch=armv5te --disable-libquadmath --disable-multilib --disable-libgomp --disable-libmudflap --enable-target-optspace --enable-threads --disable-libatomic --disable-tls --disable-nls --disable-sjlj-exceptions --disable-libstdc++-v3 --disable-libsanitizer --disable-plugins --disable-libgcc --disable-libssp --disable-docs --disable-libitm --with-gnu-as --with-gnu-ld --prefix=/home/duy/github/gcc/build";
static const char thread_model[] = "posix";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { "cpu", "arm10tdmi" }, { "arch", "armv5te" }, { "float", "soft" }, { "fpu", "vfp" }, { "tls", "gnu" } };
