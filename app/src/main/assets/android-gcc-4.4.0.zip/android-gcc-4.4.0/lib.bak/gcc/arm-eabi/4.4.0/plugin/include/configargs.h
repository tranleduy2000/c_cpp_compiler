/* Generated automatically. */
static const char configuration_arguments[] = "/home/webbb/NDK/toolchain-src//build/../gcc/gcc-4.4.0/configure --prefix=/tmp/ndk-toolchain/ndk-prebuilt-22423/toolchains/arm-eabi-4.4.0/prebuilt/android --target=arm-eabi --host=arm-linux --build=x86_64-linux-gnu --with-gnu-as --with-gnu-ld --enable-languages=c,c++ --with-gmp=/tmp/ndk/release-20110516/build/toolchain-arm-eabi-4.4.0/temp-install --with-mpfr=/tmp/ndk/release-20110516/build/toolchain-arm-eabi-4.4.0/temp-install --disable-libssp --enable-threads --disable-nls --disable-libmudflap --disable-libgomp --disable-libstdc__-v3 --disable-sjlj-exceptions --disable-shared --disable-tls --with-float=soft --with-fpu=vfp --with-arch=armv5te --enable-target-optspace --with-abi=aapcs --enable-initfini-array --disable-nls --prefix=/tmp/ndk-toolchain/ndk-prebuilt-22423/toolchains/arm-eabi-4.4.0/prebuilt/android --with-sysroot=/tmp/ndk-toolchain/ndk-prebuilt-22423/toolchains/arm-eabi-4.4.0/prebuilt/android/sysroot --with-binutils-version=2.19 --with-mpfr-version=2.3.0 --with-gcc-version=4.4.0 --with-gdb-version=6.6 --program-transform-name='s,^,arm-eabi-,'";
static const char thread_model[] = "single";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { "abi", "aapcs" }, { "arch", "armv5te" }, { "float", "soft" }, { "fpu", "vfp" } };
