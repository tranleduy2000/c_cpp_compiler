#!/system/bin/sh

echo "This is a sample program."
echo
echo "Type your age :"

read a

echo "Type your name:"

read s

echo
echo "Hello $s you're $a old."
echo
echo "Bye!"
