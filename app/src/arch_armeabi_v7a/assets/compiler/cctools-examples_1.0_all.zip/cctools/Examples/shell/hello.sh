#!/system/bin/sh

echo "Hello, World!!!"

