io.write ("What is your name? ")
name = io.read ()
print ("Hello " .. name)
