/* 

    Micro Helper Library: generic type declarations

*/

#ifndef __MHL_TYPES_H
#define __MHL_TYPES_H

typedef enum 
{
    false	= 0,
    true	= 1
} bool;

#endif
