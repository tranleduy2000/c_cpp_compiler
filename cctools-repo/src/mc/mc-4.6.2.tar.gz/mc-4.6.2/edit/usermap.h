#ifndef MC_USERMAP_H
#define MC_USERMAP_H

#define MC_USERMAP ".mc/cedit/cooledit.bindings"

#include "edit.h"

/* load user map */
gboolean edit_load_user_map(WEdit *);

#endif
