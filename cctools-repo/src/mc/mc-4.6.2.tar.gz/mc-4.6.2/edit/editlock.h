#ifndef MC_EDIT_LOCK_H
#define MC_EDIT_LOCK_H

int edit_lock_file (const char *fname);
int edit_unlock_file (const char *fname);

#endif
