#ifndef MC_VFS_FISH_H
#define MC_VFS_FISH_H

extern int fish_directory_timeout;

#endif
