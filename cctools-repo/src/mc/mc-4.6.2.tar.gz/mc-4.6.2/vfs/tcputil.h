#ifndef MC_VFS_TCPUTIL_H
#define MC_VFS_TCPUTIL_H

extern int got_sigpipe;
void tcp_init (void);

#endif
