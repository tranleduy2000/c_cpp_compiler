#ifndef MC_FIND_H
#define MC_FIND_H

void do_find (void);

#endif
