#ifndef MC_CHOWN_H
#define MC_CHOWN_H

void chown_cmd (void);

#endif
