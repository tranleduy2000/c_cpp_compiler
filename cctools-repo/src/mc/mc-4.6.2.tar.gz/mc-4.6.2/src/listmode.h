#ifndef MC_LISTMODE_H
#define MC_LISTMODE_H

#ifdef LISTMODE_EDITOR
char *listmode_edit (char*);
#endif /* LISTMODE_EDITOR */

#endif
