#ifndef MC_LEARN_H
#define MC_LEARN_H

void learn_keys (void);

#endif
