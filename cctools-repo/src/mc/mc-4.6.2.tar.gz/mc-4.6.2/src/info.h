#ifndef MC_INFO_H
#define MC_INFO_H

struct WInfo;
struct WInfo *info_new (void);

#endif
