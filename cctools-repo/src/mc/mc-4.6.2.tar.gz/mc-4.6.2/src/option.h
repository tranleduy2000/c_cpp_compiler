#ifndef MC_OPTION_H
#define MC_OPTION_H

void configure_box (void);

#endif
