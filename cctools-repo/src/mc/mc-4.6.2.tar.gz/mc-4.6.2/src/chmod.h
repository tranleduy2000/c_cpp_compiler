#ifndef MC_CHMOD_H
#define MC_CHMOD_H

void chmod_cmd (void);

#endif
