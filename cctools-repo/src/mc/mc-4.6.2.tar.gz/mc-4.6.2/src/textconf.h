#ifndef MC_TEXTCONF_H
#define MC_TEXTCONF_H

extern void show_version (int verbose);

#endif
