This directory contains the documentation of the compiler with i386 as target.
To get the documentation you've to run the pasdoc utility. You can get it from
http://pasdoc.sourceforge.net. Do a make htmldocs in the compiler directory
to create the documentation. The generated all*.html file provide access
to the different documentation.
