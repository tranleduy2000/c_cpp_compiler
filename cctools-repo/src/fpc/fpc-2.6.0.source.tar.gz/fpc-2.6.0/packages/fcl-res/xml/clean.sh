#!/bin/bash
rm *.html
rm -Rf resource
rm -Rf resourcetree
rm -Rf resdatastream
rm -Rf resfactory
rm -Rf acceleratorsresource
rm -Rf bitmapresource
rm -Rf groupresource
rm -Rf groupiconresource
rm -Rf groupcursorresource
rm -Rf stringtableresource
rm -Rf versionconsts
rm -Rf versiontypes
rm -Rf versionresource
rm -Rf resreader
rm -Rf reswriter
rm -Rf cofftypes
rm -Rf coffreader
rm -Rf coffwriter
rm -Rf winpeimagereader
rm -Rf elfconsts
rm -Rf elfreader
rm -Rf elfwriter
rm -Rf machotypes
rm -Rf machoreader
rm -Rf machowriter
rm -Rf externaltypes
rm -Rf externalreader
rm -Rf externalwriter
rm -Rf dfmreader

