The XML-RPC wrapper has been created using this command:

mkxmlrpc --input="svrclass.pp" --serverclass=TServerClass \
  --output="svrclass_xmlrpc.pp" --unitname=svrclass_XMLRPC
