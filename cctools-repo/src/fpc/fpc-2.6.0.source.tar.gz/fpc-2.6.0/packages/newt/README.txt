This is the interface to the newt screen handling library.
You need to have the newt and slang libraries installed in order to
work with this library.

The examples were provided by Patrice Dumas.
