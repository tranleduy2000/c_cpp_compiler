These units provides interface to Oracle Call Interface.

For the older 'oraoci' unit to compile you need oracle
server installed, these units was tested and performed
on Oracle 8.0.1.5 Standard server. One developer license
of Oracle server is free of charge...

Unit oraclew contains some procedures and functions,
which makes usage of oraoci not so painfull... But - 
if you wanna to program in RAW OCI, you really can ;)

The oci and ocidyn units are a complete conversion from
Oracle's .h files. The former links statically to the
library, the latter dynamically.

You need to have oracle lib directory in ldpath, too,
or you can this path set in Makefile.fpc (is commented
there)

Joost van der Sluis,
joost@cnoc.nl
