Hi/2.

This is REXX SAA interface. Nothing specific for this library. Only one thing:
This interface can be easely adapted to be used also for other OSes, not only
for OS/2. Look at Regina REXX for more info. As I know, early Regina REXX was
distributed with Win32 SDK.

About Amiga REXX. According to REXX unit source from FPC CVS tree Amiga rexx
not seems to be SAA compatible. Most portable solution is Regina REXX because
Regina supports SAA API.

Regina REXX ports available for OS/2, Win32, Unix, Amiga, QNX, BeOS & DOS.

Documentation
-------------

1. OS/2 Procedures Language 2/REXX online book
2. OS/2 Procedures Language 2/REXX Reference
3. OS/2 Procedures Language 2/REXX User Guide

Other books also available (for example, Regina REXX contains good
documentation)

wbr
Yuri
