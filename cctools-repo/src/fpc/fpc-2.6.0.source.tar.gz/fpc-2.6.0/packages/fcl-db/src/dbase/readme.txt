The maintainers of this package have abandoned it, so it has been deprecated.
It will no longer be supported by the FPC team in the future, unless someone
else volunteers to do so.

Support from other tdbf users may be available on the tdbf forum on
SourceForge: http://sourceforge.net/projects/tdbf/forums/forum/107245


TDbf readme:

See history.txt for changelog.
See history.txt for version number, latest version is at the top.
See INSTALL for installation procedure.
License is LGPL (Library General Public License); see COPYING.LIB for details.
