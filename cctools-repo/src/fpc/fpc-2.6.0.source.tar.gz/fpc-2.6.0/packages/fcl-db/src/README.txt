This is the Database directory of the Free Component Library.

All base classes are in the db unit, the dbconst unit contains the 
used resourcestrings.

memds
  contains a dataset-class in memory which can be read from, and
  written to a stream

sqldb
  contains a framework to work with several SQL-based databases
  as Interbase, Firebird, MySQL, ODBC, SQLite3 and Oracle

dbase
  contains the tDbf components, to work with DBASE and FoxPro
  file-based databases

sdf
  contains a dataset class to use text files directly as a
  database. That could be fixed-size, or limited (SDF)

sqlite
  contains datases classes to use sqlite and sqlite3

Succes !

Joost van der Sluis.              
