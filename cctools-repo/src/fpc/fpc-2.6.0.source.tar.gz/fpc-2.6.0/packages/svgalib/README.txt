This is the svgalib unit for Free Pascal.

Requirements:

To use this unit, you need at least:
 - Free Pascal 0.99.8 or higher
 - libsvga 1.2.10 or higher

Installation:

Edit the makefile to suit your setup (compile, options, where do you want to install)

Just type 'make', and all units will be compiled.
Type 'make install' to install the units.

Testing:

Two small testprograms have been provided:

vgatest : This is a translation of the C program that comes with svgalib.
testvga : Small program to demonstrate that you can draw lines on the screen in any mode.

typing 'make test' will compile the programs.

It is possible that you must be root to run these programs, 
The SVGAlib docs I have aren't clear about that.
If the programs should be able run as another user, you should make them setuid root.

I tested everything as root, and it ran smoothly, your mileage may vary, however.

Michael.
 
