Some remarks:

-Linux version requires X server running and building with GUI staff in (GUI window application).
 Tested under Linux v2.6.36 32bit, X server v1.8.2, ATI proprieraty drivers v10.10, ati stream sdk v2.2.