This package contains 2 units

uuid: 

creates a GUID based on the MAC address and Time on a linux machine.
The implementation is 100% native object pascal code.

Libuuid:
creates a GUID based on the MAC address and Time on a linux machine.
The implementation uses the libuuid.so.1 library, which should
be present on most linux systems. The library is loaded dynamically.

Both units set the OnCreateGUID event handler of SysUtils.

The test programs show the usage, tested on SuSE 9.2.

Enjoy,

Michael.
