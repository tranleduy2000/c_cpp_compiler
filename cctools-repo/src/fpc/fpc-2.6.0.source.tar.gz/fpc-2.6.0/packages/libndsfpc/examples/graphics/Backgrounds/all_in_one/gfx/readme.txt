Maps were created using the tileset provided via the Pern Editor map software by dovoto

Maps were exported individually using the grit export option.
Rotation backgrounds were exported with 8 bit tile indexes checked.

www.pernedit.com
