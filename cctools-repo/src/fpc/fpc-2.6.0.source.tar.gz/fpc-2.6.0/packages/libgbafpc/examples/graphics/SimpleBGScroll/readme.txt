

A demonstration of a simple background tile scroller for the Gameboy Advance.
Very oldschool.  Every once in a while someone comes along and either wonders
how to do it or has a problem with theirs, so I wrote this to help them out
a bit, or rather, help them understand the concept.  The source is commented
(hopefully well enough).

This was built using Wintermute's GCC toolchain for win32 environment, and
that can be found here:

http://www.devkit.tk/

or

http://homepage.ntlworld.com/wintermute2002/

Yes, you should be using this, NOT outdated toolchains.
It is leaner, faster, up to date and uses MingW env.


  Code and font by:
     r6502 (r6502ATphokos.com)
     2004-04-02

  Happy Coding!