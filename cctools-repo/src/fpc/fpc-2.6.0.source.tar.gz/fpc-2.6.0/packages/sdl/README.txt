Taken from project jedi (http://www.delphi-jedi.org/Jedi:TEAM_SDL_HOME) with permission.

Relicensed under LGPLv2 with exception as per LGPL and LGPL.addon with permission. You can use this code as long as you abide by either the LGPL + exception license, or the original MPL-1.1 license.

Currently, only SDL, SDL_Image, SDL_Mixer, SDL_gfx and SDL_ttf are compiled and installed. Additional files will be addes as I'm able to test them.

SDL_mixer_nosmpeg unit was added to provide a "smpeg-less" way to use SDL_mixer if the users don't need mp3 support and don't want to depend on the somewhat rare smpeg.dll/so/dylib. Ofcourse for this to work, you need to have a libSDL setup (eg: the libs themselves) without smpeg compiled in. It's worth the trouble in windows however...
