/*	This file is part of the software similarity tester SIM.
	Written by Dick Grune, Vrije Universiteit, Amsterdam.
	$Id: percentages.h,v 1.2 2004/08/05 09:49:48 dick Exp $
*/

extern int add_to_percentages(struct run *r);
extern void show_percentages(void);
