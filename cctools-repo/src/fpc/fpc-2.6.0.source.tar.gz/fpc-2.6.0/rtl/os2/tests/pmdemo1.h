/*******************************************

  Header f�r den Ressourcecompiler

********************************************/
#define ID_ClientWindow	1

/*

  Revision 1.3  2002/11/30 18:43:02  hajny
    * fix for missing end of comment block

  Revision 1.2  2002/09/07 16:01:25  peter
    * old logs removed and tabs fixed

*/
