All information related to WinCE port is available here: 
http://wiki.freepascal.org/WinCE_port
