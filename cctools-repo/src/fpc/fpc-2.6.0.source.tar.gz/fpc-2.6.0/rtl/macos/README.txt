The info in this file has moved to 

http://www.freepascal.org/wiki/index.php/Mode_MacPas

or to the README MacOS file accompanying the installation package.
