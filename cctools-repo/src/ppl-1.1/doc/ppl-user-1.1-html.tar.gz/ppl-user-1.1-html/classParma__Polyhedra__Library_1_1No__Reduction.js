var classParma__Polyhedra__Library_1_1No__Reduction =
[
    [ "No_Reduction", "classParma__Polyhedra__Library_1_1No__Reduction.html#a77067a656a3aa9381a93a23dfba036e4", null ],
    [ "~No_Reduction", "classParma__Polyhedra__Library_1_1No__Reduction.html#a5a0edbc51074f6e9e1a908fa292abe13", null ],
    [ "product_reduce", "classParma__Polyhedra__Library_1_1No__Reduction.html#af38e352895f910cc9556dc7ac0d8f39d", null ]
];