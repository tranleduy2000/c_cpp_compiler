var classparma__polyhedra__library_1_1Domain__Error__Exception =
[
    [ "Domain_Error_Exception", "classparma__polyhedra__library_1_1Domain__Error__Exception.html#a18ac064d1fafb42b385e6b942df648f0", null ]
];