var namespaces =
[
    [ "parma_polyhedra_library", "namespaceparma__polyhedra__library.html", null ],
    [ "Parma_Polyhedra_Library", null, null ]
];