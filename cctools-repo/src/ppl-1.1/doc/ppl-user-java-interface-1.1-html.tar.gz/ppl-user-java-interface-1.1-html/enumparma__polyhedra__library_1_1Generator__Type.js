var enumparma__polyhedra__library_1_1Generator__Type =
[
    [ "LINE", "enumparma__polyhedra__library_1_1Generator__Type.html#a3b9f75c49b0c6f00923b8f7d827ca9ad", null ],
    [ "RAY", "enumparma__polyhedra__library_1_1Generator__Type.html#aa8aee01f50041535fba84ef399e5ee81", null ],
    [ "POINT", "enumparma__polyhedra__library_1_1Generator__Type.html#a2c6506f69be68e287d31aa3db68d664b", null ]
];