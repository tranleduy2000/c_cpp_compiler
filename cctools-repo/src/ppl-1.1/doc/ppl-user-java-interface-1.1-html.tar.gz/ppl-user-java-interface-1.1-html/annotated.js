var annotated =
[
    [ "parma_polyhedra_library", "namespaceparma__polyhedra__library.html", "namespaceparma__polyhedra__library" ],
    [ "Parma_Polyhedra_Library", null, null ]
];