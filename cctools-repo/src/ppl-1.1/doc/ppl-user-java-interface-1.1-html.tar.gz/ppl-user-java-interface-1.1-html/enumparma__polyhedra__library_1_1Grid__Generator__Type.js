var enumparma__polyhedra__library_1_1Grid__Generator__Type =
[
    [ "LINE", "enumparma__polyhedra__library_1_1Grid__Generator__Type.html#a02ca1ef23d4c2b965198ea42d9d683a4", null ],
    [ "PARAMETER", "enumparma__polyhedra__library_1_1Grid__Generator__Type.html#a1a63d52277531ad7883e6679a90fdc67", null ]
];