var enumparma__polyhedra__library_1_1Optimization__Mode =
[
    [ "MINIMIZATION", "enumparma__polyhedra__library_1_1Optimization__Mode.html#aed6d879ab6fa6e6dea28b6841058c848", null ]
];