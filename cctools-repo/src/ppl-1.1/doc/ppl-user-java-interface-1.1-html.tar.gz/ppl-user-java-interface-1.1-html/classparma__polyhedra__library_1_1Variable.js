var classparma__polyhedra__library_1_1Variable =
[
    [ "Variable", "classparma__polyhedra__library_1_1Variable.html#a008168f710b00996c0183f79c23031fb", null ],
    [ "id", "classparma__polyhedra__library_1_1Variable.html#a9fb15acabc414c238c79e7c4f211c185", null ],
    [ "compareTo", "classparma__polyhedra__library_1_1Variable.html#ab54edfb4d01886f38228f56771aa085d", null ]
];