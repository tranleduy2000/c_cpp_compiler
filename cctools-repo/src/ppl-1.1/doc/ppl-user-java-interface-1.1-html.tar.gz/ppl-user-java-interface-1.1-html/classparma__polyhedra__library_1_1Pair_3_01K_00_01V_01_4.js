var classparma__polyhedra__library_1_1Pair_3_01K_00_01V_01_4 =
[
    [ "getFirst", "classparma__polyhedra__library_1_1Pair_3_01K_00_01V_01_4.html#a0f022d23c55748a9e437e1625149bf5a", null ],
    [ "getSecond", "classparma__polyhedra__library_1_1Pair_3_01K_00_01V_01_4.html#a35e4df2723c110fbdadbcde7fe9cfae0", null ]
];