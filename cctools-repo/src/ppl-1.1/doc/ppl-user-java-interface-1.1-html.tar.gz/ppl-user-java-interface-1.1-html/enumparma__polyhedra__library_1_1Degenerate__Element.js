var enumparma__polyhedra__library_1_1Degenerate__Element =
[
    [ "UNIVERSE", "enumparma__polyhedra__library_1_1Degenerate__Element.html#a9ff8417659bb4800d825f91fa8685aaf", null ]
];