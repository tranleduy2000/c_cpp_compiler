var classparma__polyhedra__library_1_1Poly__Gen__Relation =
[
    [ "Poly_Gen_Relation", "classparma__polyhedra__library_1_1Poly__Gen__Relation.html#a29127d8da5f0b833c4a89dbe3d41be27", null ],
    [ "implies", "classparma__polyhedra__library_1_1Poly__Gen__Relation.html#afe2f6db5c7f1a92104fe7efa0c301a45", null ]
];