var classparma__polyhedra__library_1_1By__Reference_3_01T_01_4 =
[
    [ "By_Reference", "classparma__polyhedra__library_1_1By__Reference_3_01T_01_4.html#ac0b40b5fd7fce9c2e70001fe21b04ecd", null ],
    [ "set", "classparma__polyhedra__library_1_1By__Reference_3_01T_01_4.html#a8be0080275e869b6858313f3ce58879e", null ],
    [ "get", "classparma__polyhedra__library_1_1By__Reference_3_01T_01_4.html#ad3af2e55a3f9bb1410625b2f98a371e1", null ]
];