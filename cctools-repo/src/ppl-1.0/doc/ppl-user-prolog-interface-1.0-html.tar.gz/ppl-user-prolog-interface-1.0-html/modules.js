var modules =
[
    [ "Prolog Language Interface", "group__PPL__Prolog__interface.html", null ],
    [ "C++ Language Interface", "../ppl-user-1.0-html/group__PPL__CXX__interface.html", "group__PPL__CXX__interface" ]
];