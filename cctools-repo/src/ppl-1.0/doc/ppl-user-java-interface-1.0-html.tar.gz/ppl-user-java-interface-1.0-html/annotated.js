var annotated =
[
    [ "", null, null ],
    [ "parma_polyhedra_library", "namespaceparma__polyhedra__library.html", "namespaceparma__polyhedra__library" ],
    [ "Parma_Polyhedra_Library", null, [
      [ "IO_Operators", null, null ],
      [ "CO_Tree", null, null ],
      [ "Linear_Expression_Interface", null, null ],
      [ "Linear_Expression_Impl", null, null ],
      [ "Implementation", null, null ]
    ] ],
    [ "std", null, null ]
];