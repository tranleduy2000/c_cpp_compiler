var classparma__polyhedra__library_1_1Logic__Error__Exception =
[
    [ "Logic_Error_Exception", "classparma__polyhedra__library_1_1Logic__Error__Exception.html#a655c21143c2eb90c64487e6e4dcd140c", null ]
];