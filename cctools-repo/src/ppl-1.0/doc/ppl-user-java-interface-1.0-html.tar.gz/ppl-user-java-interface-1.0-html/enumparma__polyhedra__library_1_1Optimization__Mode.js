var enumparma__polyhedra__library_1_1Optimization__Mode =
[
    [ "[static initializer]", "enumparma__polyhedra__library_1_1Optimization__Mode.html#aedb8628d602c447bf47249d56bf42be5", null ],
    [ "MINIMIZATION", "enumparma__polyhedra__library_1_1Optimization__Mode.html#aed6d879ab6fa6e6dea28b6841058c848", null ]
];