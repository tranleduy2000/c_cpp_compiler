var classparma__polyhedra__library_1_1IO =
[
    [ "wrap_string", "classparma__polyhedra__library_1_1IO.html#aedad05516ed695dabfa4fed118d41145", null ]
];