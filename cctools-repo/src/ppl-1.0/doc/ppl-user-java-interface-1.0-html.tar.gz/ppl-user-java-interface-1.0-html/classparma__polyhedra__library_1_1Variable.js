var classparma__polyhedra__library_1_1Variable =
[
    [ "Variable", "classparma__polyhedra__library_1_1Variable.html#aaa7f7d2e2523000e62d85670f268362a", null ],
    [ "id", "classparma__polyhedra__library_1_1Variable.html#a8d74790917f006b8ce83d9be0d356576", null ],
    [ "compareTo", "classparma__polyhedra__library_1_1Variable.html#ab54edfb4d01886f38228f56771aa085d", null ]
];