var enumparma__polyhedra__library_1_1PIP__Problem__Control__Parameter__Name =
[
    [ "CUTTING_STRATEGY", "enumparma__polyhedra__library_1_1PIP__Problem__Control__Parameter__Name.html#a1676341382601ab9c96f035983f372d5", null ],
    [ "PIVOT_ROW_STRATEGY", "enumparma__polyhedra__library_1_1PIP__Problem__Control__Parameter__Name.html#ab5cadae2d9d1e506769cafc7dd19c5b5", null ]
];