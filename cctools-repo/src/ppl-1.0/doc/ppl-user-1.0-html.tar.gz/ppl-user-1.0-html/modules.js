var modules =
[
    [ "C++ Language Interface", "group__PPL__CXX__interface.html", "group__PPL__CXX__interface" ]
];