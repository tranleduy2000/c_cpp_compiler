var structParma__Polyhedra__Library_1_1Variable_1_1Compare =
[
    [ "operator()", "structParma__Polyhedra__Library_1_1Variable_1_1Compare.html#af6c069432956f215967c61be24a40939", null ]
];